package com.students.demo.Subject.service;

import com.students.demo.Subject.mapper.SubjectMapper;
import com.students.demo.Subject.model.SubjectDto;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@RequiredArgsConstructor
@Service
public class SubjectServicempl implements SubjectService{
    private final SubjectMapper subjectMapper;

    @Override
    public List<SubjectDto> getAllsubject() {
        return List.of();
    }

    @Override
    public void deletesubject(Long id) {subjectMapper.deletesubject(id);}

    @Override
    public void updatesubject(Long id, SubjectDto updatedto){
        updatedto.setId(id);
        subjectMapper.updatesubject(updatedto);
    }
}
