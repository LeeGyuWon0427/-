package com.students.demo.Subject.controller;

import com.students.demo.Subject.model.SubjectDto;
import com.students.demo.Subject.service.SubjectService;
import lombok.RequiredArgsConstructor;
import org.apache.ibatis.annotations.Delete;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class SubjectController {
    private final SubjectService subjectService;
    @GetMapping()
    public ResponseEntity<?> getAllsubject() {
        List<SubjectDto> allsubject = subjectService.getAllsubject();
        return ResponseEntity.ok(allsubject);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletesubject(@PathVariable("id") Long id) {
        subjectService.deletesubject(id);
        return ResponseEntity.ok("삭제되었습니다.");
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updatesubject(@PathVariable("id") Long id, @RequestBody SubjectDto updatedto) {
        subjectService.updatesubject(id, updatedto);
        return ResponseEntity.ok("수정되었습니다.");
    }
}
