package com.students.demo.Subject.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SubjectDto {
    private Long id;
    private String subjectName;
    private String createdDt;
    private String updateDt;
}
