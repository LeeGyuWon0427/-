package com.students.demo.Subject.service;

import com.students.demo.Subject.model.SubjectDto;

import java.util.List;

public interface SubjectService {
    List<SubjectDto> getAllsubject();

    void deletesubject(Long id);

    void updatesubject(Long id, SubjectDto subjectDto);
}
