package com.students.demo.Subject.mapper;

import com.students.demo.Subject.model.SubjectDto;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Update;

@Mapper
public interface SubjectMapper {
    @Delete("""
            delete from subject where id = #{id};
            """)
    void deletesubject(Long id);

    @Update("""
            update subject set subject_name = #{subjectName},
            created_dt = NOW(),
            update_dt = NOW()
            where id = #{id};
            """)
    void updatesubject(SubjectDto subjectDto);
}
